dhtmlxSlider v.4.0.3 Standard edition

(c) Dinamenta, UAB.